<demo>
    使用
</demo>
<template>
    <div>
        <Cascader/>
    </div>
</template>
<script lang="ts">
    import Cascader from '../../lib/Cascader.vue'
    export default{
        components: {
            Cascader
        }
    }
</script>