<template lang="">
    
        这是Home组件
    
</template>
<script>


export default {
    setup() {
        
    },
    props:{
        name:String
    }
}
</script>
