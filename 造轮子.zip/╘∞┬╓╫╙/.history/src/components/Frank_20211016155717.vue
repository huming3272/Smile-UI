<template lang="">
    <div>
        这是一个vue组件
    </div>
</template>
<script>


export default defineComponent({
    setup() {
        
    },
    props:{
     name: '',   
    }
})
</script>
