<template lang="">
   <div>
       <Topnav/>
    <div class="content">
      <aside>边栏</aside>
      <main>主内容</main>
    </div>
  </div>
</template>
<script>
export default {
    import Topnav from ''
};
</script>
<style lang="">
</style>
