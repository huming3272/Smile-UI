<template lang="">
    
        {{name}},这是一个vue组件
    
</template>
<script>


export default {
    setup() {
        
    },
    props:{
        name:String
    }
}
</script>
