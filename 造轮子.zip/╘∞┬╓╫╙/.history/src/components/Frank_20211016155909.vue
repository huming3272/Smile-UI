<template lang="">
    <div>
        {{name}},这是一个vue组件
    </div>
</template>
<script>


export default ({
    setup() {
        
    },
    props:[name]
})
</script>
