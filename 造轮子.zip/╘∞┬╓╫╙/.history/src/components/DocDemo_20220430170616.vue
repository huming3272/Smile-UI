<template >
    <div>
        欢迎来到XXX的文档
    </div>
</template>