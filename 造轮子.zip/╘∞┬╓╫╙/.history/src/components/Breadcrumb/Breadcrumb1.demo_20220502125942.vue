<demo>
    使用
</demo>
<template>
    <div>
        Bread
    </div>
</template>
<script lang="ts">
    import Breadcrumb from '../../lib/Breadcrumb.vue'
    export default{
        components: {
            Breadcrumb
        }
    }
</script>