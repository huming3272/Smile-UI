<demo>
    使用
</demo>
<template>
    <div>
        <Breadcrumb/>
    </div>
</template>
<script lang="ts">
    import Breadcrumb from '../../lib/Breadcrumb.vue'
    export default{
        components: {
            Breadcrumb
        }
    }
</script>