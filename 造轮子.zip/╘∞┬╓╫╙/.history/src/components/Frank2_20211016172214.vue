<template lang="">
    这是frank2的组件
</template>
<script>
export default {
    
}
</script>