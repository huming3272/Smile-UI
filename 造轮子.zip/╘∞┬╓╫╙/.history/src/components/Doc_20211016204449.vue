<template lang="">
   <div>
       topnav
    <div class="content">
      <aside>边栏</aside>
      <main>主内容</main>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style lang="">
</style>
