<template>
  <div>
    <ul>
      <li>Dialog组件</li>
      
    </ul>
  </div>
</template>