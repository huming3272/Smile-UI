<template lang="">
    <div>
        只是一个vue
    </div>
</template>