<template lang="">
    <div>
        只是一个vue组件
    </div>
</template>