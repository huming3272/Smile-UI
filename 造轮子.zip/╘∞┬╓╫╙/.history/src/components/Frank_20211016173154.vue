<template lang="">
    
        {{name}},这是一个Frank组件
    
</template>
<script>


export default {
    setup() {
        
    },
    props:{
        name:String
    }
}
</script>
